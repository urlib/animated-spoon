#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
#include<cstdlib>
#include<set>
#include<queue>
#include<cmath>

#define ULL unsigned long long
int a[4][4];
using namespace std;
ULL random(ULL start,ULL end)
{
	return start + (end - start) * rand() / (RAND_MAX + 1.0);
}

void up()
{
	for(int i=1;i<=4;i++)
	{
		int m=0;
		for(int j=1;j<=3;j++)
		while(a[j][i] == 0&&m<=4)
		{
			m++;
			for(int k=j;k<=4;k++)
				a[k][i]=a[k+1][i];
				a[4][i]=0;
		}
		for(int j=1;j<=3;j++)
		while(a[j][i] == a[j+1][i] && a[j][i]!=0)
		{
			a[j][i]*=2;
			for(int k=j;k<=4;k++)
			a[k][i]=a[k+1][i];
			a[4][i]=0;
		}
	}
}

void right()
{
	for(int i=1;i<=4;i++)
	{
		for(int j=1;j<=3;j++)
		while(a[j][i] == 0)
		{
			for(int k=j;k<=4;k++)
				a[k][i]=a[k+1][i];
				a[4][i]=0;
		}
		for(int j=1;j<=3;j++)
		while(a[j][i] == a[j+1][i] && a[j][i]!=0)
		{
			a[j][i]*=2;
			for(int k=j;k<=4;k++)
			a[k][i]=a[k+1][i];
			a[4][i]=0;
		}
	}
}
int main()
{
	memset(a,0,sizeof(a));
	srand( unsigned( time(0) ) );/*������*/
	a[random(1,5)][random(1,5)]=2*random(1,3);//δ������BUG 
	a[random(1,5)][random(1,5)]=2*random(1,3);
	for(int i=1;i<=4;i++)
	{
		for(int j=1;j<=4;j++)
		printf("%5d ",a[i][j]);
		cout<<endl;
	}
	
	
	for(int i=1;i<=4;i++)		//δ�в��ܰ��� 
	{
		int m=0;
		for(int j=1;j<=3;j++)
		while(a[j][i] == 0&&m<=4)
		{
			m++;
			for(int k=j;k<=4;k++)
				a[k][i]=a[k+1][i];
				a[4][i]=0;
		}
		for(int j=1;j<=3;j++)
		while(a[j][i] == a[j+1][i] && a[j][i]!=0)
		{
			a[j][i]*=2;
			for(int k=j;k<=4;k++)
			a[k][i]=a[k+1][i];
			a[4][i]=0;
		}
	}
	char x; 
	while(cin>>x)
	{
		int l1=random(1,5),l2=random(1,5);
	for(int i=1;i<=4;i++)
	{
		for(int j=1;j<=4;j++)
		printf("%5d ",a[i][j]);
		cout<<endl;
	}
	while(a[l1][l2]!=0)
	{
			int l1=random(1,5),l2=random(1,5);
	}
	a[l1][l2]=2*random(1,3);
	for(int i=1;i<=4;i++)		//δ�в��ܰ��� 
	{
		int m=0;
		for(int j=1;j<=3;j++)
		while(a[j][i] == 0&&m<=4)
		{
			m++;
			for(int k=j;k<=4;k++)
				a[k][i]=a[k+1][i];
				a[4][i]=0;
		}
		for(int j=1;j<=3;j++)
		while(a[j][i] == a[j+1][i] && a[j][i]!=0)
		{
			a[j][i]*=2;
			for(int k=j;k<=4;k++)
			a[k][i]=a[k+1][i];
			a[4][i]=0;
		}
	}
	}
	return 0;
}
